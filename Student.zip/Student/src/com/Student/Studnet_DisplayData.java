package com.Student;

import java.util.Date;



public class Studnet_DisplayData 
{
	public
	
	int id;
	String name;
	String date;
	
	public Studnet_DisplayData(int id, String name, String date2) {
		  this.id=id;
		  this.name=name;
		  this.date=date2;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
	public void ShowData() {
		System.out.println("Studnet_GetData [id=" + id + ", name=" + name + ", date=" + date + "]"); 
	}
	@Override
	public String toString() {
		return "Studnet_DisplayData [id=" + id + ", name=" + name + ", date=" + date + "]";
	}
	
	

}




