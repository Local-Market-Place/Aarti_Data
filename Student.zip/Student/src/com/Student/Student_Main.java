package com.Student;

import java.util.Scanner;

public class Student_Main 
{

	public static void main(String[] args) 
	{
	   try (Scanner obj = new Scanner(System.in))
       {
		  System.out.println("How much  Student data you want to store ::");	
		   int n=obj.nextInt();
		   Student_GetData1 D1=new Student_GetData1(n);	  
	   }
	   catch (Exception e) {
	     e.printStackTrace();
	}

	
	
	}


	
	
}
