import java.util.Date;
public class TestPerson {

	public static void main(String[] args) {
		Person p=new Person(12,"Revati","5555",new Date());
		System.out.println(p);
	
	}

}
