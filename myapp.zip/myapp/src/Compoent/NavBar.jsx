import React from 'react'
import '../Style/Style.css' 
function NavBar() {
  return (
    <>
       <nav className="navbar">
        <div className="navbar-container container">
        <h1 className="logo">Navbar</h1>
            <ul className="menu-items">
                <li><a href="https://www.youtube.com/">Home</a></li>
                <li><a href="https://www.youtube.com/">About</a></li>
                <li><a href="https://www.youtube.com/">Category</a></li>
            </ul>
         
        </div>
    </nav>
    </>
  )
}

export default NavBar
