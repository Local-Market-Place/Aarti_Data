
import Fotter from './Fotter';
import NavBar from './NavBar';

function App() {
  return (
    <>
       <div>
       <NavBar/>
       <Fotter/>
       </div>
    </>
  );
}

export default App;
