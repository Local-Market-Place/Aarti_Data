import React from "react";
import '../Style/Style.css';
function Fotter() {
  return (
    <>
      <footer class="pc">
        <div class="copyright">
          <p> Footter </p>
        </div>
      </footer>

    </>
  );
}

export default Fotter;
