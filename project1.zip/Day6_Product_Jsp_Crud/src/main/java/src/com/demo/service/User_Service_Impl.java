package src.com.demo.service;

import src.com.demo.beans.UserData;
import src.com.demo.dao.I_UserDao;
import src.com.demo.dao.UserDao_Servic;

public class User_Service_Impl implements I_UserService {
	private I_UserDao D1;

	public User_Service_Impl() {
		D1 = new UserDao_Servic();
	}

	@Override
	public UserData validuser(String email, String password) throws ClassNotFoundException {

		return D1.Auth(email, password);
	}

}
