package src.com.demo.service;

import src.com.demo.beans.UserData;

public interface I_UserService {

	UserData validuser(String email, String password) throws ClassNotFoundException;

}
