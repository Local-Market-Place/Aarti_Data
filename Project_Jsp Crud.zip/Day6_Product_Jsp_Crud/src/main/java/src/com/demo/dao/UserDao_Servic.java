package src.com.demo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import src.com.demo.beans.UserData;

public class UserDao_Servic implements I_UserDao {

	static Connection conn;
	static PreparedStatement pvalidate;
	static {
		conn = DBUtil.getMyConnection();
		if (conn != null) {
			System.out.println("Successfully  connection");
		} else {

			System.out.println("Successfully not connection");
		}
	}

	@Override
	public UserData Auth(String email, String password) {

		try {
			PreparedStatement pst = conn.prepareStatement("INSERT INTO login values (?,?)");
			pst.setString(1, email);
			pst.setString(2, password);

			int rowsAffected = pst.executeUpdate();

			// Checking if the update was successful
			if (rowsAffected > 0) {
				System.out.println("successfully for add user: ");
			} else {
				System.out.println("No user found with the username: ");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
