package src.com.demo.dao;

import src.com.demo.beans.UserData;

public interface I_UserDao {

	UserData Auth(String email, String password);

}
